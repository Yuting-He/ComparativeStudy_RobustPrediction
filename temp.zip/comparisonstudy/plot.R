


# library
library(ggplot2)
library(reshape2)

# create data list
auc_data <- list()

# select auc value
for (method in names(results_list)) {
  for (classifier in names(results_list[[method]])) {
    for (dataset in names(results_list[[method]][[classifier]])) {
      auc_value <- as.numeric(results_list[[method]][[classifier]][[dataset]])
      auc_data[[length(auc_data) + 1]] <- data.frame(
        Method = method,
        Classifier = classifier,
        Dataset = dataset,
        AUC = auc_value
      )
    }
  }
}


auc_df <- do.call(rbind, auc_data)
print(auc_df)


# barplot
ggplot(auc_df, aes(x = Dataset, y = AUC, fill = Classifier)) +
  geom_bar(stat = "identity", position = "dodge") +
  facet_wrap(~ Method) +  
  labs(title = "AUC Values for Different Classifiers and Methods",
       x = "Dataset", y = "AUC Value") +
  theme_minimal()


# heat map
ggplot(auc_df, aes(x = Dataset, y = Classifier, fill = AUC)) +
  geom_tile() +
  facet_wrap(~ Method) +  
  labs(title = "AUC Heatmap for Different Classifiers and Methods - 15 Features",
       x = "Dataset", y = "Classifier") +
  scale_fill_gradient(low = "blue", high = "red") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))






## boxplot ##

library(ggplot2)
## dim 7
# create facet boxplot
boxplot_dim7 <- ggplot(results_df_dim7, aes(x = Method, y = Mean_AUC)) +
  geom_boxplot() +
  facet_wrap(~Classifier, scales = "free") +  
  theme_bw() +  
  theme(strip.text.x = element_text(size = 12, face = "bold")) +  
  labs(title = "Prediction performance esstimates based on independent test data (7 features)",
       x = "Tuning Method",
       y = "Mean AUC") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  

print(boxplot_dim7)

## dim 15
boxplot_dim15 <- ggplot(results_df_dim15, aes(x = Method, y = Mean_AUC)) +
  geom_boxplot() +
  facet_wrap(~Classifier, scales = "free") +  
  theme_bw() +  
  theme(strip.text.x = element_text(size = 12, face = "bold")) +  
  labs(title = "Mean AUC Value",
       x = "Tuning Method",
       y = "Mean AUC") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  

print(boxplot_dim15)


# gap constant 10
# dim 7
# create facet boxplot
boxplot_dim7_gap <- ggplot(results_df_dim7_gap, aes(x = Method, y = Mean_AUC)) +
  geom_boxplot() +
  facet_wrap(~Classifier, scales = "free") +  
  theme_bw() +  
  theme(strip.text.x = element_text(size = 12, face = "bold")) +  
  labs(title = "Prediction performance esstimates based on independent test data (7 features, feature selection with gap)",
       x = "Tuning Method",
       y = "Mean AUC") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  

print(boxplot_dim7_gap)

# gap constant 10 - gap2
# dim 7
# create facet boxplot
library(ggplot2)
boxplot_dim7_gap8 <- ggplot(results_df_dim7_gap8, aes(x = Method, y = Mean_AUC)) +
  geom_boxplot() +
  facet_wrap(~Classifier, scales = "free") +  
  theme_bw() +  
  theme(strip.text.x = element_text(size = 12, face = "bold")) +  
  labs(title = "Prediction performance esstimates based on independent test data (7 features, feature selection with gap)",
       x = "Tuning Method",
       y = "Mean AUC") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  

print(boxplot_dim7_gap8)

# plot parameter
library(ggplot2)
param_dim7_gap7 <- ggplot(results_df_dim7_gap7, aes(x = Method, y = Best_Param)) +
  geom_boxplot() +
  facet_wrap(~Classifier, scales = "free") +  
  theme_bw() +  
  theme(strip.text.x = element_text(size = 12, face = "bold")) +  
  labs(title = "Optimal values of tuning parameters (7 features, feature selection with gap)",
       x = "Tuning Method",
       y = "Optimal Hyperparameter") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  

print(param_dim7_gap7)

library(ggplot2)
param_dim15_gap7 <- ggplot(results_df_dim15_gap7, aes(x = Method, y = Best_Param)) +
  geom_boxplot() +
  facet_wrap(~Classifier, scales = "free") +  
  theme_bw() +  
  theme(strip.text.x = element_text(size = 12, face = "bold")) +  
  labs(title = "Optimal values of tuning parameters (15 features, feature selection with gap)",
       x = "Tuning Method",
       y = "Optimal Hyperparameter") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  

print(param_dim15_gap7)


# dim 15
# create facet boxplot
library(ggplot2)
boxplot_dim15_gap7 <- ggplot(results_df_dim15_gap7, aes(x = Method, y = Mean_AUC)) +
  geom_boxplot() +
  facet_wrap(~Classifier, scales = "free") +  
  theme_bw() +  
  theme(strip.text.x = element_text(size = 12, face = "bold")) +  
  labs(title = "Prediction performance esstimates based on independent test data (15 features, feature selection with gap)",
       x = "Tuning Method",
       y = "Mean AUC") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  

print(boxplot_dim15_gap7)


# importance boxplot
ggplot(importance_df, aes(y = Importance)) + 
  geom_boxplot() +
  labs(title = "Importance Boxplot", y = "Importance") +
  theme_minimal() +
  theme(axis.title.x = element_blank(), 
        axis.text.x = element_blank(),  
        axis.ticks.x = element_blank()) 