## Data preparation of the comparative study

## Objective:
## The goal is to construct two sets of low-dimensional datasets (7 dimensions and 15 dimensions) 
## using the datasets from the Ellenbach study and observe the performance of 
## different tuning methods on low-dimensional data.  

# Load the environment from scenariogrid_AUC.RData, which from Ellenbach's study
load("scenariogrid_AUC.RData")

## select 10 datasets with most observations
data_names <- paste0("data", 1:25)
data_rows <- sapply(data_names, function(x) nrow(get(x)))

data_info <- data.frame(name = data_names, rows = data_rows)

# select top 10 data sets
top_10_data <- data_info[order(-data_info$rows), ][1:10, ]

# rename data sets
for (i in 1:10) {
  assign(paste0("data_", i), get(top_10_data$name[i]))
}
# check name and observations
for (i in 1:10) {
  print(paste("Data:", paste0("data_", i), "Rows:", nrow(get(paste0("data_", i)))))
}


## feature selection
# create importance list
importance_list <- list()
reference_colnames <- NULL

for (i in 1:10) {
  data <- get(paste0("data_", i))
  
  # save column name of features
  if (is.null(reference_colnames)) {
    reference_colnames <- colnames(data)[-1]  # delete y
  } else {
    # check if column name is same as first 
    if (!all(colnames(data)[-1] == reference_colnames)) {
      stop(paste("colname unmatch! check the colname of data_", i, sep = ""))
    }
  }
  
  # random forest
  rf_model <- randomForest(x = data[, -1],  # x
                           y = data[, 1],   # y
                           importance = TRUE)
  
  importance_list[[i]] <- importance(rf_model, type = 1)  # type = 1: mean decrease of Gini
}

# check result
print(importance_list[[1]])

# importance matrix
importance_matrix <- do.call(cbind, importance_list)
# calculate mean value of each feature
importance_means <- rowMeans(importance_matrix)

# result
importance_df <- data.frame(
  Feature = reference_colnames,
  Importance = importance_means
)

importance_df <- importance_df[order(-importance_df$Importance), ]

print(importance_df)



#########  7 features  ############
top_5_features <- importance_df$Feature[1:5]
set.seed(123) 
remaining_features <- importance_df$Feature[-(1:5)]
random_features <- sample(remaining_features, 2)
selected_features <- c(top_5_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  
  new_data <- data[, c("y", selected_features)]
  
  assign(paste0("dim7_data_", i), new_data)
}


#########  15 features  ############
top_10_features <- importance_df$Feature[1:10]
set.seed(123) 
remaining_features <- importance_df$Feature[-(1:10)]
random_features <- sample(remaining_features, 5)
selected_features <- c(top_10_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  
  new_data <- data[, c("y", selected_features)]
  
  assign(paste0("dim15_data_", i), new_data)
}


# create scenario grid
datasets <- paste0("data_", 1:10)
combinations <- expand.grid(Train = datasets, External = datasets, stringsAsFactors = FALSE)

# Remove rows where Train and External are the same
combinations <- combinations[combinations$Train != combinations$External, ]

# Set random seed for scenariogrid
set.seed(123)
combinations$Seed <- sample(1:10000, nrow(combinations), replace = TRUE)

# Reset the row indices to make them continuous
rownames(combinations) <- NULL  # This resets row names to continuous indices

scenariogrid_lowdim <- combinations
print(scenariogrid_lowdim)


# save data and scenariogrid
data_names <- c(paste0("dim7_data_", 1:10), paste0("dim15_data_", 1:10))

for (name in data_names) {
  data <- get(name)
  if ("matrix" %in% class(data)) {
    data <- as.data.frame(data)
    assign(name, data)
  }
}

# Add scenariogrid_lowdim to the list of objects to be saved
save(list = c(data_names, "scenariogrid_lowdim"), file = "compare_data.Rda")



################################################
# data selection with gap - constant gap = 10, begin from 1
#  7 features
set.seed(123)
selected_indices <- c(1, 10, 20, 30, 40)
top_5_features <- importance_df$Feature[selected_indices]
remaining_features <- importance_df$Feature[-(1:40)]
random_features <- sample(remaining_features, 2)
selected_features <- c(top_5_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim7_gap_data_", i), new_data_df)
}


# 15 features
set.seed(123)
selected_indices <- c(1, 10, 20, 30, 40, 50, 60, 70, 80, 90)
top_10_features <- importance_df$Feature[selected_indices]
remaining_features <- importance_df$Feature[-(1:90)]
random_features <- sample(remaining_features, 5)
selected_features <- c(top_10_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim15_gap_data_", i), new_data_df)
}

# save data and scenariogrid
data_names <- c(paste0("dim7_gap_data_", 1:10), paste0("dim15_gap_data_", 1:10))

for (name in data_names) {
  data <- get(name)
  if ("matrix" %in% class(data)) {
    data <- as.data.frame(data)
    assign(name, data)
  }
}

# Add scenariogrid_lowdim to the list of objects to be saved
save(list = c(data_names, "scenariogrid_lowdim", "scenariogrid_lowdim_sample"), file = "compare_data_gap.Rda")



################################################
# data selection with gap2 - constant gap = 10, begin from 10
#  7 features
set.seed(123)
selected_indices <- c(10, 20, 30, 40, 50)
top_5_features <- importance_df$Feature[selected_indices]
remaining_features <- importance_df$Feature[-(1:50)]
random_features <- sample(remaining_features, 2)
selected_features <- c(top_5_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim7_gap2_data_", i), new_data_df)
}


# 15 features
set.seed(123)
selected_indices <- c(10, 20, 30, 40, 50, 60, 70, 80, 90, 100)
top_10_features <- importance_df$Feature[selected_indices]
remaining_features <- importance_df$Feature[-(1:100)]
random_features <- sample(remaining_features, 5)
selected_features <- c(top_10_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim15_gap2_data_", i), new_data_df)
}

# save data and scenariogrid
data_names <- c(paste0("dim7_gap2_data_", 1:10), paste0("dim15_gap2_data_", 1:10))

for (name in data_names) {
  data <- get(name)
  if ("matrix" %in% class(data)) {
    data <- as.data.frame(data)
    assign(name, data)
  }
}

# Add scenariogrid_lowdim to the list of objects to be saved
save(list = c(data_names, "scenariogrid_lowdim", "scenariogrid_lowdim_sample"), file = "compare_data_gap2.Rda")


################################################
# data selection with gap3 - inconstant gap 
#  7 features
set.seed(123)
selected_indices <- c(1, 10, 30, 50, 100)
top_5_features <- importance_df$Feature[selected_indices]
remaining_features <- importance_df$Feature[-(1:100)]
random_features <- sample(remaining_features, 2)
selected_features <- c(top_5_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim7_gap3_data_", i), new_data_df)
}


# 15 features
set.seed(123)
selected_indices <- c(1, 5, 10, 20, 30, 45, 60, 75, 90, 100)
top_10_features <- importance_df$Feature[selected_indices]
remaining_features <- importance_df$Feature[-(1:100)]
random_features <- sample(remaining_features, 5)
selected_features <- c(top_10_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim15_gap3_data_", i), new_data_df)
}

# save data and scenariogrid
data_names <- c(paste0("dim7_gap3_data_", 1:10), paste0("dim15_gap3_data_", 1:10))

for (name in data_names) {
  data <- get(name)
  if ("matrix" %in% class(data)) {
    data <- as.data.frame(data)
    assign(name, data)
  }
}

# Add scenariogrid_lowdim to the list of objects to be saved
save(list = c(data_names, "scenariogrid_lowdim", "scenariogrid_lowdim_sample"), file = "compare_data_gap3.Rda")


################################################
# data selection with gap4 - inconstant gap 
#  7 features
set.seed(123)
selected_indices <- c(5, 15, 30, 50, 100)
top_5_features <- importance_df$Feature[selected_indices]
remaining_features <- setdiff(importance_df$Feature, top_5_features)
random_features <- sample(remaining_features, 2)
selected_features <- c(top_5_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim7_gap4_data_", i), new_data_df)
}


# 15 features
set.seed(123)
selected_indices <- c(5, 10, 15, 25, 40, 65, 90, 120, 150, 200)
top_10_features <- importance_df$Feature[selected_indices]
remaining_features <- setdiff(importance_df$Feature, top_10_features)
random_features <- sample(remaining_features, 5)
selected_features <- c(top_10_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim15_gap4_data_", i), new_data_df)
}

# save data and scenariogrid
data_names <- c(paste0("dim7_gap4_data_", 1:10), paste0("dim15_gap4_data_", 1:10))

for (name in data_names) {
  data <- get(name)
  if ("matrix" %in% class(data)) {
    data <- as.data.frame(data)
    assign(name, data)
  }
}

# Add scenariogrid_lowdim to the list of objects to be saved
save(list = c(data_names, "scenariogrid_lowdim", "scenariogrid_lowdim_sample"), file = "compare_data_gap4.Rda")


################################################
# data selection with gap6 - inconstant gap, begin from 2nd
#  7 features
set.seed(123)
selected_indices <- c(2, 3, 5, 10, 50)
top_5_features <- importance_df$Feature[selected_indices]
remaining_features <- importance_df$Feature[-(1:50)]
random_features <- sample(remaining_features, 2)
selected_features <- c(top_5_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim7_gap6_data_", i), new_data_df)
}


# 15 features
set.seed(123)
selected_indices <- c(2, 3, 5, 8, 12, 16, 21, 28, 38, 50)
top_10_features <- importance_df$Feature[selected_indices]
remaining_features <- importance_df$Feature[-(1:50)]
random_features <- sample(remaining_features, 5)
selected_features <- c(top_10_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim15_gap6_data_", i), new_data_df)
}

# save data and scenariogrid
data_names <- c(paste0("dim7_gap6_data_", 1:10), paste0("dim15_gap6_data_", 1:10))

for (name in data_names) {
  data <- get(name)
  if ("matrix" %in% class(data)) {
    data <- as.data.frame(data)
    assign(name, data)
  }
}

# Add scenariogrid_lowdim to the list of objects to be saved
save(list = c(data_names, "scenariogrid_lowdim", "scenariogrid_lowdim_sample"), file = "compare_data_gap6.Rda")

################################################
# data selection with gap7 - inconstant gap, begin from 2nd
#  7 features
set.seed(123)
selected_indices <- c(2, 3, 4, 5, 10)
top_5_features <- importance_df$Feature[selected_indices]
remaining_features <- importance_df$Feature[-(1:10)]
random_features <- sample(remaining_features, 2)
selected_features <- c(top_5_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim7_gap7_data_", i), new_data_df)
}


# 15 features
set.seed(123)
selected_indices <- c(2, 3, 4, 5, 7, 10, 15, 20, 30, 50)
top_10_features <- importance_df$Feature[selected_indices]
remaining_features <- importance_df$Feature[-(1:50)]
random_features <- sample(remaining_features, 5)
selected_features <- c(top_10_features, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim15_gap7_data_", i), new_data_df)
}

# save data and scenariogrid
data_names <- c(paste0("dim7_gap7_data_", 1:10), paste0("dim15_gap7_data_", 1:10))

for (name in data_names) {
  data <- get(name)
  if ("matrix" %in% class(data)) {
    data <- as.data.frame(data)
    assign(name, data)
  }
}

# Add scenariogrid_lowdim to the list of objects to be saved
save(list = c(data_names, "scenariogrid_lowdim", "scenariogrid_lowdim_sample"), file = "compare_data_gap7.Rda")


################################################
# data selection randomly include 1st
#  7 features
set.seed(123)
top_feature <- importance_df$Feature[1]
remaining_features <- importance_df$Feature[-1]
random_features <- sample(remaining_features, 6)
selected_features <- c(top_feature, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim7_ram_data_", i), new_data_df)
}


# 15 features
set.seed(123)
top_feature <- importance_df$Feature[1]
remaining_features <- importance_df$Feature[-1]
random_features <- sample(remaining_features, 14)
selected_features <- c(top_feature, random_features)

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim15_ram_data_", i), new_data_df)
}

# save data and scenariogrid
data_names <- c(paste0("dim7_ram_data_", 1:10), paste0("dim15_ram_data_", 1:10))

for (name in data_names) {
  data <- get(name)
  if ("matrix" %in% class(data)) {
    data <- as.data.frame(data)
    assign(name, data)
  }
}

# Add scenariogrid_lowdim to the list of objects to be saved
save(list = c(data_names, "scenariogrid_lowdim", "scenariogrid_lowdim_sample"), file = "compare_data_ram.Rda")


################################################
# data selection with gap8 - inconstant gap, begin from 2nd
#  7 features
set.seed(123)
selected_indices <- c(2, 3, 4, 5, 6, 7, 8)
selected_features <- importance_df$Feature[selected_indices]

for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim7_gap8_data_", i), new_data_df)
}


# 15 features
set.seed(123)
selected_indices <- c(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16)
selected_features <- importance_df$Feature[selected_indices]


for (i in 1:10) {
  data <- get(paste0("data_", i))
  new_data <- data[, c("y", selected_features)]
  new_data_df <- as.data.frame(new_data)
  assign(paste0("dim15_gap8_data_", i), new_data_df)
}

# save data and scenariogrid
data_names <- c(paste0("dim7_gap8_data_", 1:10), paste0("dim15_gap8_data_", 1:10))

for (name in data_names) {
  data <- get(name)
  if ("matrix" %in% class(data)) {
    data <- as.data.frame(data)
    assign(name, data)
  }
}

# Add scenariogrid_lowdim to the list of objects to be saved
save(list = c(data_names, "scenariogrid_lowdim", "scenariogrid_lowdim_sample"), file = "compare_data_gap8.Rda")



# the whole experiment in compare_study.R
####################################
## probe test for 2 data - dim 7

# boosting
set.seed(123)
result_robusttunec <- tuneandtrain(data = dim7_data_2, dataext = dim7_data_6, tuningmethod = "robusttunec", classifier = "boosting")
result_ext <- tuneandtrain(data = dim7_data_2, dataext = dim7_data_6, tuningmethod = "ext", classifier = "boosting")
result_int <- tuneandtrain(data = dim7_data_2, dataext = dim7_data_6, tuningmethod = "int", classifier = "boosting")

if(!require(pROC)) {
  install.packages("pROC")
  library(pROC)
}

# create result list
auc_boosting <- list()
tuning_methods <- c("robusttunec", "ext", "int")

# validation use rest data sets
for (method in tuning_methods) {
  result <- tuneandtrain(data = dim7_data_2, dataext = dim7_data_6, tuningmethod = method, classifier = "boosting")
  
  auc_results <- list()
  
  for (i in c(1, 3:5, 7:10)) {
    data <- get(paste0("dim7_data_", i))
    predictions <- predict(result$best_model, newdata = data[, -1], type = "response")
    auc_value <- pROC::auc(response = data[, 1], predictor = predictions)
    auc_results[[paste0("dim7_data_", i)]] <- auc_value
  }
  
  auc_boosting[[method]] <- auc_results
}

print(auc_boosting)


## method + classifier

# create result list
results_list_7 <- list()

# define tuning methods and classifiers
tuning_methods <- c("robusttunec", "ext", "int")
classifiers <- c("boosting", "lasso", "ridge", "rf", "svm")

# prediction
for (method in tuning_methods) {
  results_list_7[[method]] <- list()
  
  for (classifier in classifiers) {
    # print actual method and classifier
    cat("Running with method:", method, "and classifier:", classifier, "\n")
    
    result <- tuneandtrain(data = dim7_data_2, dataext = dim7_data_6, tuningmethod = method, classifier = classifier)
    auc_results <- list()
    
    for (i in c(1, 3:5, 7:10)) {
      data <- get(paste0("dim7_data_", i))
      
      # NA
      if (anyNA(data)) {
        data <- na.omit(data)
      }
      
      # choose prediction method
      if (classifier == "lasso") {
        predictions <- predict(result$best_model, newx = as.matrix(data[, -1]), s = result$best_lambda, type = "response")
        predicted_classes <- as.numeric(predictions)
        
      } else if (classifier == "ridge") {
        predictions <- predict(result$best_model, newx = as.matrix(data[, -1]), s = result$best_lambda, type = "response")
        predicted_classes <- as.numeric(predictions)
        
      } else if (classifier == "boosting") {
        predictions <- predict(result$best_model, newdata = as.matrix(data[, -1]), type = "response")
        predicted_classes <- as.numeric(predictions)
        
      } else if (classifier == "rf") {
        
        if ("ranger" %in% class(result$best_model)) {
          predictions <- predict(result$best_model, data = data)$predictions
          predicted_classes <- predictions[, 1]  
          
        } else if ("WrappedModel" %in% class(result$best_model)) {
          pred_result <- predict(result$best_model, newdata = data)
          predicted_classes <- pred_result$data$prob.1  
          
        } else {
          stop("Unknown rf model type.")
        }
        
      } else if (classifier == "svm") {
        data$y <- as.factor(data$y)  
        pred_result <- predict(result$best_model, newdata = data)
        predicted_classes <- as.numeric(pred_result$data$response)  
        
      } else {
        stop("Unknown classifier")
      }
      
      # print length of response and predictions
      print(paste("Data:", paste0("dim7_data_", i)))
      print(paste("Length of response:", length(data[, 1])))
      print(paste("Length of predictions:", length(predicted_classes)))
      
      # calculate AUC
      if (length(data[, 1]) == length(predicted_classes)) {
        auc_value <- pROC::auc(response = as.numeric(data[, 1]), predictor = predicted_classes)
        print(paste("AUC for", paste0("dim7_data_", i), ":", auc_value))
        
        # save result
        auc_results[[paste0("dim7_data_", i)]] <- auc_value
      } else {
        stop(paste("Length mismatch in data:", paste0("dim7_data_", i)))
      }
    }
    
    results_list_7[[method]][[classifier]] <- auc_results
  }
}

print(results_list_7)


## 15 features
# create result list
results_list_15 <- list()

# define tuning methods and classifiers
tuning_methods <- c("robusttunec", "ext", "int")
classifiers <- c("boosting", "lasso", "ridge", "rf", "svm")

# prediction
for (method in tuning_methods) {
  results_list_15[[method]] <- list()
  
  for (classifier in classifiers) {
    # print actual method and classifier
    cat("Running with method:", method, "and classifier:", classifier, "\n")
    
    result <- tuneandtrain(data = dim15_data_2, dataext = dim15_data_6, tuningmethod = method, classifier = classifier)
    auc_results <- list()
    
    for (i in c(1, 3:5, 7:10)) {
      data <- get(paste0("dim15_data_", i))
      
      # NA
      if (anyNA(data)) {
        data <- na.omit(data)
      }
      
      # choose prediction method
      if (classifier == "lasso") {
        predictions <- predict(result$best_model, newx = as.matrix(data[, -1]), s = result$best_lambda, type = "response")
        predicted_classes <- as.numeric(predictions)
        
      } else if (classifier == "ridge") {
        predictions <- predict(result$best_model, newx = as.matrix(data[, -1]), s = result$best_lambda, type = "response")
        predicted_classes <- as.numeric(predictions)
        
      } else if (classifier == "boosting") {
        predictions <- predict(result$best_model, newdata = as.matrix(data[, -1]), type = "response")
        predicted_classes <- as.numeric(predictions)
        
      } else if (classifier == "rf") {
          pred_result <- predict(result$best_model, newdata = data)
          predicted_classes <- pred_result$data$prob.1  
        
      } else if (classifier == "svm") {
        data$y <- as.factor(data$y)  
        pred_result <- predict(result$best_model, newdata = data)
        predicted_classes <- as.numeric(pred_result$data$response)  
        
      } else {
        stop("Unknown classifier")
      }
      
      # print length of response and predictions
      print(paste("Data:", paste0("dim15_data_", i)))
      print(paste("Length of response:", length(data[, 1])))
      print(paste("Length of predictions:", length(predicted_classes)))
      
      # calculate AUC
      if (length(data[, 1]) == length(predicted_classes)) {
        auc_value <- pROC::auc(response = as.numeric(data[, 1]), predictor = predicted_classes)
        print(paste("AUC for", paste0("dim15_data_", i), ":", auc_value))
        
        # save result
        auc_results[[paste0("dim15_data_", i)]] <- auc_value
      } else {
        stop(paste("Length mismatch in data:", paste0("dim15_data_", i)))
      }
    }
    
    results_list_15[[method]][[classifier]] <- auc_results
  }
}

print(results_list_15)