# function run_experiment - original
run_experiment <- function(dim, index) {
  
  load("D:/statistik/thesis/compare_data.Rda")
  
  Train_name <- scenariogrid_lowdim$Train[index]
  External_name <- scenariogrid_lowdim$External[index]
  seed <- scenariogrid_lowdim$Seed[index]
  
  # Dynamically get the train and external datasets
  Train <- get(paste0("dim", dim, "_", Train_name))
  External <- get(paste0("dim", dim, "_", External_name))
  
  # Define the results dataframe to store the output
  results_df <- data.frame(
    Method = character(),
    Classifier = character(),
    Train = character(),
    External = character(),
    Mean_AUC = numeric(),
    Best_Param = character(),  # New column for the best parameter
    stringsAsFactors = FALSE
  )
  
  # Create an empty list to store error information
  error_log <- list()
  
  # Set the seed for reproducibility
  set.seed(seed)
  
  # Define tuning methods and classifiers
  tuning_methods <- c("robusttunec", "ext", "int")
  classifiers <- c("boosting", "lasso", "ridge", "rf", "svm")
  
  # Perform experiments for each method and classifier
  for (method in tuning_methods) {
    for (classifier in classifiers) {
      # Try running the experiment, handle errors gracefully
      try_result <- try({
        # Print the method and classifier
        cat("Running with method:", method, "and classifier:", classifier, "\n")
        
        # Train the model using tuneandtrain
        model_result <- tuneandtrain(data = Train, dataext = External, tuningmethod = method, classifier = classifier)
        auc_results <- numeric()  # Initialize to empty numeric vector
        best_param <- NA  # Initialize best_param
        
        # Validation using the remaining 8 datasets
        for (i in setdiff(1:10, as.numeric(c(Train_name, External_name)))) {
          data <- get(paste0("dim", dim, "_data_", i))
          
          # Handle NA values
          if (anyNA(data)) {
            data <- na.omit(data)
          }
          
          # Choose prediction method based on classifier
          if (classifier %in% c("lasso", "ridge")) {
            predictions <- predict(model_result$best_model, newx = as.matrix(data[, -1]), s = model_result$best_lambda, type = "response")
            predicted_classes <- as.numeric(predictions)
            best_param <- model_result$best_lambda  # Store the best lambda
            
          } else if (classifier == "boosting") {
            predictions <- predict(model_result$best_model, newdata = as.matrix(data[, -1]), type = "response")
            predicted_classes <- as.numeric(predictions)
            best_param <- model_result$best_mstop  # Store the best mstop
            
          } else if (classifier == "rf") {
            pred_result <- predict(model_result$best_model, newdata = data)
            predicted_classes <- pred_result$data$prob.1
            best_param <- model_result$best_min_node_size  # Store the best min.node.size
            
          } else if (classifier == "svm") {
            data$y <- as.factor(data$y)
            pred_result <- predict(model_result$best_model, newdata = data)
            predicted_classes <- as.numeric(pred_result$data$response)
            best_param <- model_result$best_cost  # Store the best cost for SVM
            
          } else {
            stop("Unknown classifier")
          }
          
          # Check for length mismatch
          if (length(data[, 1]) == length(predicted_classes)) {
            auc_value <- pROC::auc(response = as.numeric(data[, 1]), predictor = predicted_classes)
            auc_results <- c(auc_results, auc_value)
          } else {
            stop(paste("Length mismatch in data:", paste0("dim", dim, "_data_", i)))
          }
        }
        
        # Calculate the mean AUC across the 8 validation datasets
        mean_auc <- if(length(auc_results) > 0) mean(auc_results, na.rm = TRUE) else NA
        
        # Add results to dataframe
        results_df <- rbind(results_df, data.frame(
          Method = method,
          Classifier = classifier,
          Train = Train_name,
          External = External_name,
          Mean_AUC = mean_auc,
          Best_Param = best_param,  # Store the best parameter
          stringsAsFactors = FALSE
        ))
        
      }, silent = TRUE)  # Use silent to suppress error messages
      
      # If there was an error, log NA for this combination and save the error message
      if (inherits(try_result, "try-error")) {
        error_message <- paste("Error in method:", method, "classifier:", classifier, "Train:", Train_name, "External:", External_name, "\nError:", try_result)
        cat(error_message, "\n")
        error_log[[length(error_log) + 1]] <- error_message  # Add error message to log
        
        # Add NA results to dataframe, ensure all columns have values
        results_df <- rbind(results_df, data.frame(
          Method = method,
          Classifier = classifier,
          Train = Train_name,
          External = External_name,
          Mean_AUC = NA,
          Best_Param = NA,  # Log NA for the parameter
          stringsAsFactors = FALSE
        ))
      }
    }
  }
  
  # Return both the result dataframe and error log
  return(list(results = results_df, errors = error_log))
}

# test run
result_test <- run_experiment(7,1)


##############################################
# function run_experiment - gap
run_experiment <- function(dim, index, scenariogrid) {
  
  Train_name <- scenariogrid$Train[index]
  External_name <- scenariogrid$External[index]
  seed <- scenariogrid$Seed[index]
  
  # Dynamically get the train and external datasets
  Train <- get(paste0("dim", dim, "_", Train_name))
  External <- get(paste0("dim", dim, "_", External_name))
  
  # Define the results dataframe to store the output
  results_df <- data.frame(
    Method = character(),
    Classifier = character(),
    Train = character(),
    External = character(),
    Mean_AUC = numeric(),
    Best_Param = character(),  # New column for the best parameter
    stringsAsFactors = FALSE
  )
  
  # Create an empty list to store error information
  error_log <- list()
  
  # Set the seed for reproducibility
  set.seed(seed)
  
  # Define tuning methods and classifiers
  tuning_methods <- c("robusttunec", "ext", "int")
  classifiers <- c("boosting", "lasso", "ridge", "rf", "svm")
  
  # Perform experiments for each method and classifier
  for (method in tuning_methods) {
    for (classifier in classifiers) {
      # Try running the experiment, handle errors gracefully
      try_result <- try({
        # Print the method and classifier
        cat("Running with method:", method, "and classifier:", classifier, "\n")
        
        # Train the model using tuneandtrain
        model_result <- tuneandtrain(data = Train, dataext = External, tuningmethod = method, classifier = classifier)
        auc_results <- numeric()  # Initialize to empty numeric vector
        best_param <- NA  # Initialize best_param
        
        # Validation using the remaining 8 datasets
        for (i in setdiff(1:10, as.numeric(c(Train_name, External_name)))) {
          data <- get(paste0("dim", dim, "_data_", i))
          
          # Handle NA values
          if (anyNA(data)) {
            data <- na.omit(data)
          }
          
          # Choose prediction method based on classifier
          if (classifier %in% c("lasso", "ridge")) {
            predictions <- predict(model_result$best_model, newx = as.matrix(data[, -1]), s = model_result$best_lambda, type = "response")
            predicted_classes <- as.numeric(predictions)
            best_param <- model_result$best_lambda  # Store the best lambda
            
          } else if (classifier == "boosting") {
            predictions <- predict(model_result$best_model, newdata = as.matrix(data[, -1]), type = "response")
            predicted_classes <- as.numeric(predictions)
            best_param <- model_result$best_mstop  # Store the best mstop
            
          } else if (classifier == "rf") {
            pred_result <- predict(model_result$best_model, newdata = data)
            predicted_classes <- pred_result$data$prob.1
            best_param <- model_result$best_min_node_size  # Store the best min.node.size
            
          } else if (classifier == "svm") {
            data$y <- as.factor(data$y)
            pred_result <- predict(model_result$best_model, newdata = data)
            predicted_classes <- as.numeric(pred_result$data$response)
            best_param <- model_result$best_cost  # Store the best cost for SVM
            
          } else {
            stop("Unknown classifier")
          }
          
          # Check for length mismatch
          if (length(data[, 1]) == length(predicted_classes)) {
            auc_value <- pROC::auc(response = as.numeric(data[, 1]), predictor = predicted_classes)
            auc_results <- c(auc_results, auc_value)
          } else {
            stop(paste("Length mismatch in data:", paste0("dim", dim, "_data_", i)))
          }
        }
        
        # Calculate the mean AUC across the 8 validation datasets
        mean_auc <- if(length(auc_results) > 0) mean(auc_results, na.rm = TRUE) else NA
        
        # Add results to dataframe
        results_df <- rbind(results_df, data.frame(
          Method = method,
          Classifier = classifier,
          Train = Train_name,
          External = External_name,
          Mean_AUC = mean_auc,
          Best_Param = best_param,  # Store the best parameter
          stringsAsFactors = FALSE
        ))
        
      }, silent = TRUE)  # Use silent to suppress error messages
      
      # If there was an error, log NA for this combination and save the error message
      if (inherits(try_result, "try-error")) {
        error_message <- paste("Error in method:", method, "classifier:", classifier, "Train:", Train_name, "External:", External_name, "\nError:", try_result)
        cat(error_message, "\n")
        error_log[[length(error_log) + 1]] <- error_message  # Add error message to log
        
        # Add NA results to dataframe, ensure all columns have values
        results_df <- rbind(results_df, data.frame(
          Method = method,
          Classifier = classifier,
          Train = Train_name,
          External = External_name,
          Mean_AUC = NA,
          Best_Param = NA,  # Log NA for the parameter
          stringsAsFactors = FALSE
        ))
      }
    }
  }
  
  # Return both the result dataframe and error log
  return(list(results = results_df, errors = error_log))
}




##############################################
# run experiment - all
dims <- c(7, 15)
num_scenarios <- nrow(scenariogrid_lowdim)

# initial result df
results_df_dim7 <- data.frame(
  Method = character(),
  Classifier = character(),
  Train = character(),
  External = character(),
  Mean_AUC = numeric(),
  Best_Param = character(),
  stringsAsFactors = FALSE
)

results_df_dim15 <- data.frame(
  Method = character(),
  Classifier = character(),
  Train = character(),
  External = character(),
  Mean_AUC = numeric(),
  Best_Param = character(),
  stringsAsFactors = FALSE
)

# initial error list
errors_dim7 <- list()
errors_dim15 <- list()

# iterate all index from dim and scenariogrid 
for (dim in dims) {
  for (index in 1:num_scenarios) {
    cat("Running experiment for dim:", dim, "index:", index, "\n")
    
    # run_experiment 
    experiment_result <- run_experiment(dim, index)
    
    # save result by dim 
    if (dim == 7) {
      results_df_dim7 <- rbind(results_df_dim7, experiment_result$results)
      errors_dim7 <- c(errors_dim7, experiment_result$errors)
      
      # print current results_df_dim7
      cat("Current state of results_df_dim7 after iteration", index, ":\n")
      print(results_df_dim7)
      
    } else if (dim == 15) {
      results_df_dim15 <- rbind(results_df_dim15, experiment_result$results)
      errors_dim15 <- c(errors_dim15, experiment_result$errors)
      
      # print current results_df_dim15
      cat("Current state of results_df_dim15 after iteration", index, ":\n")
      print(results_df_dim15)
    }
  }
}

# 打印最终结果
cat("Results for dim 7:\n")
print(results_df_dim7)

cat("\nResults for dim 15:\n")
print(results_df_dim15)

# 如果有错误信息，可以查看
if (length(errors_dim7) > 0) {
  cat("\nErrors occurred during some experiments for dim 7:\n")
  print(errors_dim7)
}

if (length(errors_dim15) > 0) {
  cat("\nErrors occurred during some experiments for dim 15:\n")
  print(errors_dim15)
}

print(results_all)





############################### 7 and 15 seperately ########################
# run run_experiment()
library(RobustPrediction)
# 7 features - sample scenariogrid
dim <- "7_gap8"
scenario <- scenariogrid_lowdim  
num_scenarios <- nrow(scenario)

# create result data frame
results_df_dim7_gap8 <- data.frame(
  Method = character(),
  Classifier = character(),
  Train = character(),
  External = character(),
  Mean_AUC = numeric(),
  Best_Param = character(),
  stringsAsFactors = FALSE
)

# create error list
errors_dim7_gap8 <- list()

# Set the save frequency 
save_frequency <- 5

for (index in 1:num_scenarios) {
  cat("Running experiment for dim 7, index:", index, "\n")
  
  experiment_result <- run_experiment(dim, index, scenariogrid = scenario)
  
  # save result into df
  results_df_dim7_gap8 <- rbind(results_df_dim7_gap8, experiment_result$results)
  errors_dim7_gap8 <- c(errors_dim7_gap8, experiment_result$errors)
  
  # print actual results_df_dim7
  cat("Current state of results_df_dim7_gap8 after iteration", index, ":\n")
  print(results_df_dim7_gap8)
  
  # Save the latest result every `save_frequency` iterations
  if (index %% save_frequency == 0) {
    save(results_df_dim7_gap8, errors_dim7_gap8, file = "results_df_dim7_gap8_latest.Rda")
  }
}

# print
print(results_df_dim7_gap8)
if (length(errors_dim7_gap8) > 0) {
  cat("\nErrors occurred during some experiments for dim 7:\n")
  print(errors_dim7_gap8)
}

# save result
save(results_df_dim7_gap8, file = "results_df_dim7_gap8.Rda")


####################################
# 15 features
dim <- "15_gap8"
scenario <- scenariogrid_lowdim  
num_scenarios <- nrow(scenario)

# create result data frame
results_df_dim15_gap8 <- data.frame(
  Method = character(),
  Classifier = character(),
  Train = character(),
  External = character(),
  Mean_AUC = numeric(),
  Best_Param = character(),
  stringsAsFactors = FALSE
)

# create error list
errors_dim15_gap8 <- list()

# Set the save frequency 
save_frequency <- 5

for (index in 1:num_scenarios) {
  cat("Running experiment for dim 15, index:", index, "\n")
  
  experiment_result <- run_experiment(dim, index, scenariogrid = scenario)
  
  # save result into df
  results_df_dim15_gap8 <- rbind(results_df_dim15_gap8, experiment_result$results)
  errors_dim15_gap8 <- c(errors_dim15_gap8, experiment_result$errors)
  
  # print actual results_df_dim15
  cat("Current state of results_df_dim15_gap8 after iteration", index, ":\n")
  print(results_df_dim15_gap8)
  
  # Save the latest result every `save_frequency` iterations
  if (index %% save_frequency == 0) {
    save(results_df_dim15_gap8, errors_dim15_gap8, file = "results_df_dim15_gap8_latest.Rda")
  }
}

# print
print(results_df_dim15_gap8)
if (length(errors_dim15_gap8) > 0) {
  cat("\nErrors occurred during some experiments for dim 7:\n")
  print(errors_dim15_gap8)
}

# save result
save(results_df_dim15_gap8, file = "results_df_dim15_gap8.Rda")


